# 立创EDA Pro 键盘 PCB 自动摆放工具

把 KLE 键盘布局自动展开成 PCB 上 KEY/D/LED/C 的精确坐标 + 旋转,
然后用一个 JS 脚本一次性摆好所有元件。

适用场景:分体键盘、自定义键盘等矩阵式 PCB,通常有几十个按键 ×
4 个相关元件 = 100+ 元件要摆放,手动拖太费时间。

---

## 文件清单

| 文件 | 作用 |
|---|---|
| `compute_positions.py` | 解析 KLE → 算出每个元件的 mm 坐标,写成 CSV |
| `generate_script.py` | 读 CSV → 转 mil → 生成立创EDA JS 脚本 |
| `diagnose.js` | 通用诊断脚本,新环境先跑这个验证 API 行为 |
| `positions.csv` | (生成) 所有元件位号 + 坐标 + 旋转 |
| `place_components.js` | (生成) 最终要在立创EDA 跑的脚本 |

---

## 标准工作流

### 第 1 步:准备布局和原理图

1. 在 [keyboard-layout-editor.com](http://www.keyboard-layout-editor.com/) 画好键盘布局,复制 "Raw data" 标签里的 JSON
2. 在立创EDA 里画好原理图,确定矩阵行划分(哪些键属于 ROW1、ROW2...)
3. 在 PCB 里**手动放置第一个键**(K1,通常是布局左上角那个),记下它的视觉坐标(mm)

### 第 2 步:填配置

编辑 `compute_positions.py` 顶部的 `CONFIG`:

- `layout`: 粘贴 KLE JSON(注意把 `true`/`false`/`null` 改成 Python 的 `True`/`False`/`None`)
- `matrix_rows`: 每一行对应矩阵的一行,列出该行的所有键(用 KLE 标签字符串)
- `anchor`: 第一个键的 KLE 标签 + 它在 PCB 上的视觉 mm 坐标
- `offsets`: D / LED / C 相对 KEY 的偏移(通常不用改,跟元件封装走)
- `designators`: PCB 上实际位号的前缀(`KEY` / `K` / `SW` 等)

### 第 3 步:生成

```bash
python3 compute_positions.py   # 输出 positions.csv
python3 generate_script.py     # 输出 place_components.js
```

### 第 4 步:在立创EDA 里跑

1. 打开 PCB 文件,**先备份**(另存为)
2. 顶部菜单 → 高级 → 扩展管理器 → 运行脚本(或直接 Ctrl+/ 调出脚本对话框)
3. 粘贴 `place_components.js` 内容,按 F9
4. 等待"✅ 成功 N / N"弹窗

---

## 踩坑笔记(血泪经验)

### 单位:API 用 mil,不是 mm ⚠

立创EDA Pro 的 `setState_X/setState_Y` 内部**使用 mil 作为单位**,不管你在编辑器里把显示单位设成什么。所以发给 API 之前**必须把 mm 乘以 `1/0.0254 ≈ 39.3701`**。

`getState_X/Y` 读回来的也是 mil。读写一致,所以只看 API 数字会被误导 —
必须**用眼睛看 PCB 画布**才知道单位对不对。

`generate_script.py` 已经自动做了这个转换,CSV 里存的还是 mm(便于人读),
生成 JS 时才换算。

### API 调用方式:链式 + 只 await done()

`setState_X / setState_Y / setState_Rotation` 都是**同步**方法,返回的是**新实例**(immutable / 链式构建器模式)。必须链起来用,只对最后的 `done()` 用 `await`(只有它返回 `Promise`):

```javascript
// ✅ 正确
const comp = await eda.pcb_PrimitiveComponent.get(id);
await comp.setState_X(x).setState_Y(y).setState_Rotation(r).done();

// ❌ 错误: 链断了, X/Y 设置全丢了
await comp.setState_X(x);
await comp.setState_Y(y);
await comp.setState_Rotation(r);
await comp.done();
```

### 不要用 `modify()`

`PCB_PrimitiveComponent.modify(id, { x, y, rotation })` 看起来很方便,但是 BETA 接口,论坛报告有 bug(会把元件翻到底层),而且字段名容易踩坑(`positionX/positionY` 是错的,接受 `x/y` 但有副作用)。

直接用 `setState` 链 + `done()` 最稳。

### 坐标系

- **KLE 是 Y 向下**(屏幕坐标),**PCB 是 Y 向上**(数学坐标)。转换公式翻 Y。
- **旋转方向**:PCB 用 CCW(逆时针)为正度数;KLE 的 `r` 是 CW(顺时针)。所以 `PCB_rotation = -KLE_r`。

### Z 序(K1, K2, K3... 的编号顺序)

按**矩阵行**分组,每行内按**物理 cx**(KLE 中心 x)从左到右排序。这一点很重要:

- 矩阵行决定 LED 朝向(LED 链蛇形走线,奇行 180° / 偶行 0°)
- 矩阵行决定电容左/右位置(跟着 LED 翻)
- **旋转的拇指簇也按 cx 排序**,不要单独丢到最后

如果你的 PCB 原理图里 KEY22 是 ROW4 的最左侧(比如 Backspace),Z 序就把它编为 K22(而不是按其他规则)。

### 验证步骤(强烈推荐)

新键盘第一次跑的时候,**不要一上来就跑批量脚本**。流程是:

1. 跑 `compute_positions.py` 后,先看输出的 Z 序列表对不对,跟你原理图的位号对应不对得上
2. 检查 CSV 里 K1 和某个对角键(比如左半的 Delete、右半的 →End)的坐标,跟你预期的 mm 位置一致
3. 跑 `diagnose.js` 在新 PCB 上确认 API 能正常移动一个元件
4. 用眼睛看 KEY1 视觉上跑到的位置 = 你预期的 mil 位置 ÷ 25.4 mm
5. 都对了再跑 `place_components.js`

### 撤销

**跑脚本前先 Ctrl+S 保存**,这样万一摆错了可以 Ctrl+Z 一次性撤销(或者直接关掉不保存重新打开)。立创EDA 撤销大量元件的撤销栈不太稳,**保存是更可靠的回退点**。

---

## 配置示例:常见变形

### 左右两半板分开做

- 各做一份 `compute_positions.py` 的副本(`compute_left.py` / `compute_right.py`)
- 每份的 `CONFIG.name` 改成 `"left"` / `"right"`
- 各自的 KLE 布局和锚点
- 输出不同的 CSV(改 `output_csv` 字段)

### 没有 LED 链 / 没有电容

- 把 `offsets` 里不需要的元件改成 `None`
- 改 `compute_positions.py` 的 `compute_positions()` 函数,跳过 None 的元件
- 或者更简单:只生成 KEY+D 两类,LED/C 部分注释掉

### 不同的元件偏移

- 每个项目的元件封装可能不同,先在立创EDA 里**手动放好一组**(KEY + D + LED + C),记下相对偏移
- 填到 `CONFIG.offsets`

### 不同尺寸的键(2U Space 等)

- KLE 已经自动处理(w/h 属性),`compute_positions.py` 计算 cx 时会考虑
- 偏移量针对的是中心点,不管键多大都一样

---

## 故障排查

| 现象 | 可能原因 | 排查 |
|---|---|---|
| 所有元件都堆在原点附近 | 没做 mm→mil 转换 | 确认用了 `generate_script.py` 生成的 JS,不要直接喂 CSV 数字 |
| 元件位置整体偏一段距离 | 锚点 mm 坐标填错 | 量一下实际 K1 的位置,改 `CONFIG.anchor` |
| 旋转方向反了 | KLE/PCB 旋转约定混了 | 检查 `PCB_rotation = -KLE_r`,在代码里是 `K_rot = -k['r_KLE']` |
| LED 朝向都一样,没有蛇形 | 矩阵行分配错了 | 看 `compute_positions.py` 输出的 ROW 分配,跟原理图对一下 |
| 拇指簇位置不对 | KLE 的 `rx/ry` 旋转中心填错 | 在 KLE 网页上检查 r/rx/ry 三个值 |
| API 报"找不到位号" | PCB 上的位号跟 CSV 不一致 | 改 `CONFIG.designators` 前缀,或在 PCB 上批量改位号 |

---

## API 参考

立创EDA 专业版扩展 API 文档:
- 主页:https://prodocs.lceda.cn/cn/api/reference/pro-api.html
- 用到的接口:
  - `eda.pcb_PrimitiveComponent.getAllPrimitiveId()` — 拉所有元件 ID
  - `eda.pcb_PrimitiveComponent.get(id)` — 拿到元件实例
  - `instance.getState_Designator()` / `getState_X()` / `getState_Y()` / `getState_Rotation()` / `getState_Layer()` — 读属性
  - `instance.setState_X(x).setState_Y(y).setState_Rotation(r).done()` — 链式设属性
  - `eda.sys_MessageBox.showInformationMessage(msg, title)` — 弹窗
  - `eda.sys_ToastMessage.showMessage(msg, seconds)` — Toast

注意所有 BETA 接口可能在后续版本变化,出问题先查最新文档。
