#!/usr/bin/env python3
"""
键盘 PCB 自动摆放 - 坐标计算

输入: 这个文件下方的 CONFIG (KLE 布局 + 矩阵行定义 + 锚点)
输出: positions.csv (所有元件的位号/x/y/旋转)

下次新键盘只改 CONFIG 块, 不用改其他代码.
"""
import math
import csv
import json
import sys

# ============================================================
# 配置区 - 下次新键盘只改这里
# ============================================================
CONFIG = {
    # ── 标识 (影响输出文件名) ────────────────────
    "name": "right",        # 例如 "right" / "left" / "macro_pad"
    
    # ── KLE 布局 ─────────────────────────────────
    # 从 keyboard-layout-editor.com 复制 "Raw data" 标签里的内容
    # 注意是 Python 列表语法 (true→True, false→False, null→None)
    "layout": [
        [{"x":3.3},"*\n8"],
        [{"y":-0.875,"x":4.3},"(\n9"],
        [{"y":-0.75,"x":1.3},"^\n6","&\n7"],
        [{"y":-0.875,"x":5.3},")\n0","—\n\n\n\n\n\n-","+\n\n\n\n\n\n="],
        [{"y":-0.5,"x":3.3},"I\n↑"],
        [{"y":-0.875,"x":4.3},"O"],
        [{"y":-0.75,"x":1.3},"Y","U"],
        [{"y":-0.875,"x":5.3},"P","{\n\n\n\n\n\n[","}\n\n\n\n\n\n]"],
        [{"y":-0.5,"x":3.3},"K\n↓"],
        [{"y":-0.875,"x":4.3},"L\n→"],
        [{"y":-0.75,"x":1.3},"H","J\n←"],
        [{"y":-0.875,"x":5.3},":\n;","'\n\n\n\n\n\n\"","\\\n|"],
        [{"y":-0.5,"x":3.3},"<\n,"],
        [{"y":-0.875,"x":4.3},">\n."],
        [{"y":-0.75,"x":1.3},"N","M"],
        [{"y":-0.875,"x":5.3},"?\n/","↑\nPgUp","~\n\n\n\n\n\n`"],
        [{"y":-0.8,"x":0.3},"Back\n\n\n\n\n\nSpace"],
        [{"y":-0.2,"x":3.5,"w":1.25},"Ctrl",{"x":0.55},"←\nHome","↓\nPgDN","→\nEnd"],
        [{"r":-40,"rx":1.585,"ry":5.9953,"y":-1.25,"x":-1,"h":1.25},"\n\nright"],
        [{"r":-23,"rx":2.5055,"ry":5.6045,"y":-1.25,"x":-1,"h":1.25},"Space\nEnter"],
        [{"r":-6,"rx":3.5,"ry":5.5,"y":-1,"x":-1},"Fn"]
    ],
    
    # ── 矩阵行定义 ────────────────────────────────
    # 每个矩阵行包含哪些键 (用 KLE 里的标签字符串原样填)
    # - 决定 K1, K2, ... 的 Z 序编号
    # - 决定 LED 朝向 (奇数行 180°, 偶数行 0°)
    # - 同一行内按物理 cx 自动排序 (左→右)
    "matrix_rows": {
        1: ["^\n6", "&\n7", "*\n8", "(\n9", ")\n0", "—\n\n\n\n\n\n-", "+\n\n\n\n\n\n="],
        2: ["Y", "U", "I\n↑", "O", "P", "{\n\n\n\n\n\n[", "}\n\n\n\n\n\n]"],
        3: ["H", "J\n←", "K\n↓", "L\n→", ":\n;", "'\n\n\n\n\n\n\"", "\\\n|"],
        4: ["N", "M", "<\n,", ">\n.", "?\n/", "↑\nPgUp", "~\n\n\n\n\n\n`",
            "Back\n\n\n\n\n\nSpace"],
        5: ["Ctrl", "←\nHome", "↓\nPgDN", "→\nEnd",
            "\n\nright", "Space\nEnter", "Fn"]
    },
    
    # ── 锚点: 第一个键(K1, 最左上)的 PCB 视觉坐标 ──
    # 在立创EDA 里先手动放好这一个键, 记下它的位置作为基准
    "anchor": {
        "label": "^\n6",        # KLE 标签
        "x_mm": 44.798,         # PCB 视觉 x (mm)
        "y_mm": 113.967,        # PCB 视觉 y (mm), Y 向上为正
    },
    
    # ── 单键间距 ──────────────────────────────────
    "U_mm": 19.05,
    
    # ── 元件相对偏移 (mm, 相对于 KEY 中心) ──────
    # 旋转用 CCW 为正, 单位度
    "offsets": {
        # 二极管: 所有行都一样
        "D": {
            "dx": 7.620, "dy": 2.675, "rotation": 270,
        },
        # LED: 朝向跟矩阵行奇偶有关 (LED 链蛇形走线)
        "LED": {
            "dx": 0, "dy": 5.080,
            "rotation_odd_row":  180,
            "rotation_even_row": 0,
        },
        # 电容: 跟着 LED 朝向左右翻
        "C_odd_row":  {"dx":  5.737, "dy": 5.010, "rotation": 270},
        "C_even_row": {"dx": -5.736, "dy": 5.150, "rotation":  90},
    },
    
    # ── 位号前缀 ──────────────────────────────────
    "designators": {
        "KEY": "KEY",   # 按键
        "D":   "D",     # 二极管
        "LED": "LED",   # RGB LED
        "C":   "C",     # 电容
    },
    
    # ── 输出 CSV 路径 ─────────────────────────────
    "output_csv": "positions.csv",
}


# ============================================================
# 下面是处理代码, 一般不用改
# ============================================================

def parse_kle(layout):
    """解析 KLE JSON, 返回每个键的中心 cx/cy (U 单位, KLE y 向下) + KLE 旋转角."""
    keys = []
    r = rx = ry = 0
    cx = cy = 0.0
    w = h = 1.0
    for row in layout:
        cx = rx
        for item in row:
            if isinstance(item, dict):
                if 'r'  in item: r  = item['r']
                if 'rx' in item: rx = item['rx']; cx = rx; cy = ry
                if 'ry' in item: ry = item['ry']; cy = ry; cx = rx
                if 'x'  in item: cx += item['x']
                if 'y'  in item: cy += item['y']
                if 'w'  in item: w  = item['w']
                if 'h'  in item: h  = item['h']
            else:
                # 这是一个按键标签
                key_cx_pre = cx + w / 2
                key_cy_pre = cy + h / 2
                # 应用旋转: 围绕 (rx, ry) 旋转 r 度 (KLE 方向: 顺时针为正)
                th = math.radians(r)
                dx = key_cx_pre - rx
                dy = key_cy_pre - ry
                keys.append({
                    'label':  item,
                    'cx_U':   rx + dx * math.cos(th) - dy * math.sin(th),
                    'cy_U':   ry + dx * math.sin(th) + dy * math.cos(th),
                    'r_KLE':  r,
                })
                cx += w
                w = h = 1.0
        cy += 1.0
        cx = rx
    return keys


def assign_matrix_rows(keys, matrix_rows):
    """把每个键分配到矩阵行, 在行内按 cx 升序排, 返回 K1...Kn 的有序列表."""
    label_to_row = {}
    for row_idx, labels in matrix_rows.items():
        for lbl in labels:
            label_to_row[lbl] = row_idx
    
    ordered = []
    for row_idx in sorted(matrix_rows.keys()):
        in_row = [k for k in keys if label_to_row.get(k['label']) == row_idx]
        expected = len(matrix_rows[row_idx])
        if len(in_row) != expected:
            found_labels = [k['label'] for k in in_row]
            missing = set(matrix_rows[row_idx]) - set(found_labels)
            extra = set(found_labels) - set(matrix_rows[row_idx])
            raise ValueError(
                f"矩阵行 ROW{row_idx} 期望 {expected} 个键, 实际找到 {len(in_row)} 个.\n"
                f"  缺失: {missing}\n  多余: {extra}\n"
                f"  检查 CONFIG['matrix_rows'][{row_idx}] 的标签拼写"
            )
        # 行内按 cx 升序
        in_row.sort(key=lambda k: k['cx_U'])
        for k in in_row:
            k['matrix_row'] = row_idx
            ordered.append(k)
    return ordered


def rotate_offset(dx, dy, angle_deg):
    """绕原点旋转一个偏移向量."""
    t = math.radians(angle_deg)
    return (dx * math.cos(t) - dy * math.sin(t),
            dx * math.sin(t) + dy * math.cos(t))


def compute_positions(config):
    keys = parse_kle(config['layout'])
    ordered = assign_matrix_rows(keys, config['matrix_rows'])
    
    # 找到锚点键, 用它的 cx_U/cy_U 跟它的 PCB 坐标建立映射
    anchor_label = config['anchor']['label']
    anchor_key = next((k for k in ordered if k['label'] == anchor_label), None)
    if anchor_key is None:
        raise ValueError(f"锚点键 '{anchor_label}' 找不到, 检查 CONFIG['anchor']['label']")
    
    anchor_cx_U = anchor_key['cx_U']
    anchor_cy_U = anchor_key['cy_U']
    anchor_x_mm = config['anchor']['x_mm']
    anchor_y_mm = config['anchor']['y_mm']
    U = config['U_mm']
    
    def kle_to_pcb(cx_U, cy_U):
        # KLE y 向下, PCB y 向上, 要翻转
        return (anchor_x_mm + (cx_U - anchor_cx_U) * U,
                anchor_y_mm - (cy_U - anchor_cy_U) * U)
    
    off = config['offsets']
    designators = config['designators']
    
    rows_out = []
    for idx, k in enumerate(ordered, 1):
        Kx, Ky = kle_to_pcb(k['cx_U'], k['cy_U'])
        # KLE 顺时针正, PCB CCW 正 → 旋转角取反
        K_rot = -k['r_KLE']
        is_odd = (k['matrix_row'] % 2 == 1)
        
        # 选偏移
        d_off  = off['D']
        led    = off['LED']
        c_off  = off['C_odd_row'] if is_odd else off['C_even_row']
        led_base_rot = led['rotation_odd_row'] if is_odd else led['rotation_even_row']
        
        # 偏移要跟着 K 旋转
        d_dx,  d_dy  = rotate_offset(d_off['dx'],  d_off['dy'],  K_rot)
        l_dx,  l_dy  = rotate_offset(led['dx'],    led['dy'],    K_rot)
        c_dx,  c_dy  = rotate_offset(c_off['dx'],  c_off['dy'],  K_rot)
        
        # 元件旋转 = 基础旋转 + K 旋转
        norm = lambda a: ((a % 360) + 360) % 360
        
        rows_out.append((f"{designators['KEY']}{idx}", Kx,       Ky,       norm(K_rot)))
        rows_out.append((f"{designators['D']}{idx}",   Kx+d_dx,  Ky+d_dy,  norm(d_off['rotation'] + K_rot)))
        rows_out.append((f"{designators['LED']}{idx}", Kx+l_dx,  Ky+l_dy,  norm(led_base_rot + K_rot)))
        rows_out.append((f"{designators['C']}{idx}",   Kx+c_dx,  Ky+c_dy,  norm(c_off['rotation'] + K_rot)))
    
    return rows_out, ordered


def write_csv(rows, path):
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['位号', 'x(mm)', 'y(mm)', '旋转(度)'])
        for n, x, y, a in rows:
            w.writerow([n, f"{x:.3f}", f"{y:.3f}", f"{a:g}"])


def print_summary(ordered):
    print(f"解析出 {len(ordered)} 个键, K 编号顺序:")
    for i, k in enumerate(ordered, 1):
        lbl = k['label'].replace('\n', '/').replace('\\', '\\\\')[:18]
        rot = f" (KLE 旋转 {k['r_KLE']}°)" if k['r_KLE'] != 0 else ""
        print(f"  K{i:2d} ROW{k['matrix_row']}: {lbl}{rot}")


def main():
    rows, ordered = compute_positions(CONFIG)
    print_summary(ordered)
    write_csv(rows, CONFIG['output_csv'])
    print(f"\n✓ 写入 {CONFIG['output_csv']} ({len(rows)} 行 = {len(ordered)} 键 × 4 元件)")
    print(f"  下一步: 跑 generate_script.py 把 CSV 变成 JS")


if __name__ == '__main__':
    main()
