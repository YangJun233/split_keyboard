#!/usr/bin/env python3
"""
键盘 PCB 自动摆放 - 从 CSV 生成立创EDA 脚本

读 positions.csv → 写 place_components.js
关键: 自动把 mm 乘以 1/0.0254 转换成 mil (因为立创EDA Pro API 内部用 mil)
"""
import csv
import sys
import os

# ============================================================
# 配置
# ============================================================
INPUT_CSV   = "positions.csv"
OUTPUT_JS   = "place_components.js"

# 单位转换: 立创EDA Pro 的 setState_X/Y 内部用 mil
# 不要被骗, getState_X 读回的也是 mil, 但显示在编辑器里是 mm
MM_TO_MIL = 1.0 / 0.0254   # ≈ 39.3700787

# ============================================================

JS_TEMPLATE = '''// ============================================================
// 立创EDA 专业版 - PCB 元件批量摆放脚本
// 自动生成自 {csv_name}, 共 {count} 个元件
// ============================================================
// API 使用注意:
//   1. setState_X/Y 内部单位是 mil, 不是 mm (CSV 里的 mm 已经在生成时换算过了)
//   2. setState_X/Y/Rotation 是 SYNC 同步方法, 返回新实例, 必须链式调用
//   3. 只 await 最后的 done() (它是 async Promise)
//   4. 不要用 modify() — BETA 接口有 bug (会翻层 + 字段名不接受)
// ============================================================

(async function () {{
  // 数据格式: [位号, x(mil), y(mil), 旋转(度)]
  const positions = [
{data}
  ];

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  // 获取 PCB 上所有元件 ID
  let allIds;
  try {{
    allIds = await eda.pcb_PrimitiveComponent.getAllPrimitiveId();
  }} catch (e) {{
    await eda.sys_MessageBox.showInformationMessage(
      "无法获取 PCB 元件列表: " + e.message + "\\n请确认当前焦点在 PCB 编辑器", "出错");
    return;
  }}

  // 建立 位号 -> primitiveId 索引
  const idMap = {{}};
  for (const id of allIds) {{
    const info = await eda.pcb_PrimitiveComponent.get(id);
    try {{
      const d = info.getState_Designator();
      if (d) idMap[d] = id;
    }} catch (e) {{}}
  }}

  eda.sys_ToastMessage.showMessage("开始摆放 " + positions.length + " 个元件...", 2);

  let success = 0, fail = 0;
  const failNames = [];
  const missing = [];

  for (const [name, x, y, rotRaw] of positions) {{
    const primId = idMap[name];
    if (!primId) {{ missing.push(name); continue; }}
    const rotation = ((rotRaw % 360) + 360) % 360;
    try {{
      // 链式调用, 只 await done()
      const comp = await eda.pcb_PrimitiveComponent.get(primId);
      await comp.setState_X(x).setState_Y(y).setState_Rotation(rotation).done();
      success++;
    }} catch (err) {{
      fail++;
      failNames.push(name + ": " + (err.message || err));
    }}
    await sleep(5);  // 给画布留一点刷新时间
  }}

  // 汇总
  let result = "✅ 成功 " + success + " / " + positions.length;
  if (missing.length) {{
    result += "\\n找不到位号 (" + missing.length + "): " + missing.slice(0, 10).join(", ");
    if (missing.length > 10) result += " ...";
  }}
  if (failNames.length) {{
    result += "\\n失败:\\n" + failNames.slice(0, 5).join("\\n");
  }}
  await eda.sys_MessageBox.showInformationMessage(result, "摆放完成");
}})();
'''


def main():
    if not os.path.exists(INPUT_CSV):
        print(f"✗ 找不到 {INPUT_CSV}, 请先跑 compute_positions.py")
        sys.exit(1)
    
    with open(INPUT_CSV, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)
    
    # 转换 mm -> mil, 拼数据行
    data_lines = []
    for i in range(0, len(rows), 4):
        quad = rows[i:i+4]
        parts = []
        for n, x_mm, y_mm, a in quad:
            x_mil = float(x_mm) * MM_TO_MIL
            y_mil = float(y_mm) * MM_TO_MIL
            parts.append(f'["{n}",{x_mil:>10.3f},{y_mil:>10.3f},{float(a):>5g}]')
        data_lines.append("    " + ", ".join(parts) + ",")
    
    js = JS_TEMPLATE.format(
        csv_name=INPUT_CSV,
        count=len(rows),
        data="\n".join(data_lines),
    )
    
    with open(OUTPUT_JS, 'w', encoding='utf-8') as f:
        f.write(js)
    
    print(f"✓ 写入 {OUTPUT_JS}")
    print(f"  - 输入: {len(rows)} 行 mm 坐标")
    print(f"  - 单位转换: mm × {MM_TO_MIL:.6f} = mil")
    print(f"  示例: KEY1 ({rows[0][1]} mm, {rows[0][2]} mm) -> "
          f"({float(rows[0][1])*MM_TO_MIL:.3f} mil, {float(rows[0][2])*MM_TO_MIL:.3f} mil)")
    print(f"\n  下一步: 复制 {OUTPUT_JS} 内容, 在立创EDA 里运行")


if __name__ == '__main__':
    main()
