// ============================================================
// 立创EDA 通用诊断脚本
// ============================================================
// 跑这个之前, 先在 PCB 上确保有至少一个名为 KEY1 的元件
// (改下面的 TARGET 常量也可以测别的位号)
// ============================================================
// 用法:
//   1. 在新 PCB 上, 还没跑批量脚本前, 先跑这个验证 API 行为
//   2. 看 [A] [C] 等方法测试的结果, 确认能正常移动元件
//   3. 重点: 跑完之后用眼睛看! 看 TARGET 是不是真的视觉上跑到了 (X_TEST, Y_TEST)
//      如果 API 报告位置和视觉位置一致 → API 单位 = 当前显示单位
//      如果不一致 → 有单位偏差或坐标系偏移
// ============================================================

(async function () {
  const TARGET = "KEY1";
  
  // 测试位置 (mil — 立创EDA Pro API 内部单位)
  // 100 mil = 2.54 mm
  // 如果你 PCB 显示单位是 mm, 视觉上 KEY1 应该跑到 2.54 mm 附近
  const X_TEST = 4000;   // mil ≈ 101.6 mm
  const Y_TEST = 4000;   // mil ≈ 101.6 mm

  // 找 TARGET
  const allIds = await eda.pcb_PrimitiveComponent.getAllPrimitiveId();
  let primId = null;
  for (const id of allIds) {
    const info = await eda.pcb_PrimitiveComponent.get(id);
    try {
      if (info.getState_Designator() === TARGET) { primId = id; break; }
    } catch (e) {}
  }
  if (!primId) {
    await eda.sys_MessageBox.showInformationMessage("找不到 " + TARGET, "出错");
    return;
  }

  async function snapshot(tag) {
    const c = await eda.pcb_PrimitiveComponent.get(primId);
    const get = (fn) => { try { return c[fn](); } catch (e) { return "?"; } };
    return tag + ": x=" + get("getState_X") +
                 ", y=" + get("getState_Y") +
                 ", rot=" + get("getState_Rotation") +
                 ", layer=" + JSON.stringify(get("getState_Layer"));
  }

  const log = [];
  log.push(await snapshot("初始"));

  // [A] modify with {x, y, rotation}
  try {
    await eda.pcb_PrimitiveComponent.modify(primId, { x: X_TEST, y: Y_TEST, rotation: 90 });
    log.push("\\n[A] modify({x,y,rotation}): 调用成功");
  } catch (e) { log.push("\\n[A] modify 报错: " + e.message); }
  log.push(await snapshot("[A] 之后"));

  // [C] 链式 setState + done
  try {
    const c = await eda.pcb_PrimitiveComponent.get(primId);
    await c.setState_X(X_TEST + 500).setState_Y(Y_TEST + 500).setState_Rotation(45).done();
    log.push("\\n[C] setState链 + done: 调用成功");
  } catch (e) { log.push("\\n[C] setState链 报错: " + e.message); }
  log.push(await snapshot("[C] 之后"));

  log.push("\\n\\n⚠ 现在用眼睛看 PCB:");
  log.push("  - " + TARGET + " 视觉上跑到哪里去了?");
  log.push("  - 如果 PCB 显示单位是 mm, [C] 后视觉位置应在");
  log.push("    (" + ((X_TEST+500)*0.0254).toFixed(3) + "mm, " +
                     ((Y_TEST+500)*0.0254).toFixed(3) + "mm) 附近");
  log.push("  - 不对的话, 把视觉坐标告诉 AI 重新算转换公式");

  const msg = log.join("\\n");
  await eda.sys_MessageBox.showInformationMessage(msg, "诊断结果");
  console.log(msg);
})();
